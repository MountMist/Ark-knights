import os

def rename_images_in_folder(folder_path, prefix='enemy_L3_ZZ', start_number=0):
    # 检查给定路径是否有效且是一个目录
    if not os.path.isdir(folder_path):
        print(f"错误：'{folder_path}' 不是有效的文件夹路径")
        return
    
    # 获取文件夹中所有的文件
    files = os.listdir(folder_path)
    
    # 过滤出.jpg 和 .png 文件
    image_extensions = ['.jpg', '.jpeg', '.png']
    images = [file for file in files if any(file.lower().endswith(ext) for ext in image_extensions)]
    
    # 对找到的图片文件进行排序，以确保按名称顺序重命名
    images.sort()
    
    # 遍历图片列表并重命名
    for index, old_name in enumerate(images):
        # 构造新的文件名
        new_name = f"{prefix}{start_number + index}{os.path.splitext(old_name)[1]}"
        
        # 构造完整的旧文件名和新文件名路径
        old_file = os.path.join(folder_path, old_name)
        new_file = os.path.join(folder_path, new_name)
        
        # 重命名文件
        os.rename(old_file, new_file)
        print(f"重命名 '{old_name}' 到 '{new_name}'")

# 使用示例
folder_path = './level3/ZZ-LOOP'  # 替换为你的图片文件夹路径
rename_images_in_folder(folder_path)